# SOP-002: Western Blot Membrane Blocking
## Protocol
1. After protein transfer, wash the PVDF membrane twice with TBST for 5 minutes each.
2. Prepare the blocking buffer by dissolving 5g of non-fat dry milk in 100mL of TBST (5% w/v).
3. Fully submerge the membrane in the blocking buffer.
4. Incubate for 1 hour at room temperature on an orbital shaker.
5. Do not use BSA as the blocking agent for phospho-specific antibodies.