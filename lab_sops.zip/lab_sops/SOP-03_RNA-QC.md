# SOP-003: RNA Extraction Quality Control
## QC Steps
1. After extraction, quantify the RNA concentration using a NanoDrop spectrophotometer.
2. The A260/A280 ratio is a critical measure of purity. A ratio of ~2.0 is generally
accepted as 'pure' for RNA. Ratios significantly lower may indicate protein contamination.
3. The A260/A230 ratio should be in the range of 2.0-2.2. Lower values may indicate
contaminants like phenol or guanidine salts.
4. Samples with poor purity ratios should not be used for downstream applications like qPCR.