# SOP-001: Daily Cell Culture Contamination Check
## Procedure
1. Visually inspect all flasks and plates under a microscope each morning.
2. Look for cloudiness in the media, which indicates bacterial contamination.
3. Check the media color. A rapid shift to yellow indicates bacterial growth,
while a shift to purple indicates fungal contamination.
4. All our standard culture media (DMEM, RPMI) should be supplemented
with 1% Penicillin-Streptomycin to minimize risk.
